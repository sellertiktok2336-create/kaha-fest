# KAHA FEST 2027 — Website Resmi

Landing page KAHA FEST 2027. Festival musik satu hari di GOR Uncak Kapuas, Kabupaten Kapuas Hulu, Kalimantan Barat. Sabtu, 23 Januari 2027, 18.00-23.00 WIB.

Website statis (satu file `index.html`, semua gambar sudah tertanam). Tidak perlu build.

## Deploy ke Vercel
1. Upload repo ini ke GitHub.
2. Buka vercel.com → login dengan GitHub → Import repo ini.
3. Framework Preset: Other, biarkan setting default → Deploy.

## Update konten
Edit langsung `index.html`:
- **Link/nomor WhatsApp tiket**: cari tulisan `WHATSAPP_LINK` di bagian `<script>` paling bawah.
- **Harga tiket**: cari tulisan `Segera Diumumkan`, ganti dengan harga asli saat sudah diumumkan.
- Teks lineup, rundown, FAQ: cari langsung nama talent / kalimatnya.

Tiket dijual via WhatsApp admin **+62 823-4873-4447** (pesan awal chat terisi otomatis).

Setiap commit baru di GitHub akan otomatis di-deploy ulang oleh Vercel.
