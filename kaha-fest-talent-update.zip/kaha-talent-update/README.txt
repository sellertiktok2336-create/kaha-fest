KAHA FEST - UPDATE FOTO TALENT

Isi ZIP ini:
- 9 foto talent di public/talents/
- File Lineup.tsx yang menampilkan foto pada kartu lineup
- File kahafest.ts yang menambahkan path foto untuk 9 talent

Cara memasang dari root project Codespaces:
1. Upload ZIP ini ke folder root project (sejajar package.json).
2. Jalankan: unzip -o kaha-fest-talent-update.zip
3. Periksa perubahan, lalu jalankan git status.
4. Commit dan push sesuai panduan ChatGPT.
